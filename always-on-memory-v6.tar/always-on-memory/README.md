# always-on-memory

An always-on AI memory agent with **Rgano-inspired edge detection** and **trait extraction**, built in Rust.

Unlike flat memory systems that just store and retrieve, this agent understands the **topology** of your knowledge — where ideas connect, where they diverge, and where the interesting boundaries live.

## What makes this different

| Google's approach | This approach |
|---|---|
| SQLite flat store | DuckDB columnar analytics |
| No dimensionality to memories | 16-axis trait vectors per memory |
| Consolidation = summarize | Consolidation = edge-aware synthesis |
| "What connections exist?" | "Where does consensus break down?" |
| Python daemon | Rust async daemon (Tokio) |
| Flash-Lite only | Any LLM (Ollama, OpenAI-compat) |

### Rgano Edge Detection

Core insight: `edge_score(x) = 1 - consensus(x, neighbors(x))`

In memory space, "neighbors" are memories sharing topics or entities. "Consensus" is measured by trait vector similarity. **High edge scores reveal where related knowledge diverges** — these are the most valuable consolidation targets and the most informative boundaries to surface during queries.

### Trait Extraction

Every memory gets a trait vector along axes like `technical↔creative`, `theoretical↔practical`, `cautious↔bold`. This isn't just metadata — it's the basis for consensus measurement. Two memories about "AI agents" that score differently on `cautious↔bold` represent a genuine tension worth surfacing.

## Quick Start

```bash
# Configure your LLM endpoint
cp config.toml my_config.toml
# Edit my_config.toml — set your Ollama or OpenAI-compatible endpoint

# Build and run
cargo build --release
./target/release/always-on-memory

# Or with a custom config
./target/release/always-on-memory my_config.toml
```

## Usage

### Drop files in the inbox
```bash
echo "AI agents need persistent memory to be useful" > inbox/note.txt
cp research_paper.md inbox/
# Auto-ingested within seconds
```

### HTTP API
```bash
# Ingest text
curl -X POST http://localhost:8888/ingest \
  -H "Content-Type: application/json" \
  -d '{"text": "DuckDB is an in-process analytical database", "source": "notes"}'

# Query with topology awareness
curl "http://localhost:8888/query?q=what+do+I+know+about+databases"

# Check stats
curl http://localhost:8888/status

# View detected knowledge boundaries
curl http://localhost:8888/edges

# Trigger manual consolidation
curl -X POST http://localhost:8888/consolidate

# List all memories
curl http://localhost:8888/memories

# Delete a memory
curl -X POST http://localhost:8888/delete \
  -H "Content-Type: application/json" \
  -d '{"memory_id": 1}'
```

## Configuration

See `config.toml` for all options:

- **server** — host/port for the HTTP API
- **watcher** — inbox directory and poll interval
- **consolidation** — timer interval, minimum batch size, edge threshold
- **llm** — endpoint URL, model name, optional API key
- **database** — DuckDB file path
- **traits** — number of trait dimensions (default 16)

## LLM Backend

Any OpenAI-compatible endpoint works. Just change `config.toml`:

```toml
# Ollama (Linux/Mac/Windows)
[llm]
base_url = "http://localhost:11434"
model = "llama3.1:8b"

# LocalAI (Linux/Mac/Windows, Docker)
[llm]
base_url = "http://localhost:8080"
model = "gemma-3-12b-it"

# exo (distributed cluster, auto-discovery)
[llm]
base_url = "http://localhost:52415"
model = "mlx-community/Llama-3.2-1B-Instruct-4bit"

# OpenAI / any cloud provider
[llm]
base_url = "https://api.openai.com"
model = "gpt-4o"
api_key = "sk-..."
```

## LocalAGI Integration

This project includes a **drop-in LocalRecall-compatible API**, so you can replace
LocalAGI's default memory backend with topology-aware, edge-detecting memory.

Point LocalAGI at this daemon instead of LocalRecall:

```bash
# In your LocalAGI docker-compose or env:
LOCALAGI_LOCALRAG_URL=http://always-on-memory:8888
```

The `/api/collections/*` endpoints match LocalRecall's contract:

```bash
# Create a collection
curl -X POST http://localhost:8888/api/collections \
  -H "Content-Type: application/json" \
  -d '{"name":"myCollection"}'

# Add content
curl -X POST http://localhost:8888/api/collections/myCollection/upload \
  -H "Content-Type: application/json" \
  -d '{"content":"AI agents need persistent memory", "source":"notes.txt"}'

# Search (topology-aware, not flat vector similarity)
curl -X POST http://localhost:8888/api/collections/myCollection/search \
  -H "Content-Type: application/json" \
  -d '{"query":"what do I know about memory?", "max_results":5}'

# List entries
curl http://localhost:8888/api/collections/myCollection/entries

# Reset
curl -X POST http://localhost:8888/api/collections/myCollection/reset
```

The difference: when LocalAGI searches memory through us, it gets back not just
matching documents but **edge-aware synthesis** — tensions, contradictions, and
cross-cutting insights that flat RAG can never surface.

## Architecture

```
                    ┌──────────────┐
                    │  inbox/      │  file watcher
                    │  *.txt *.md  │──────────┐
                    └──────────────┘           │
                                              ▼
  POST /ingest ─────────────────────► ┌──────────────┐
                                      │   Ingest     │
                                      │   Engine     │
                                      │  (LLM extract│
                                      │   + traits)  │
                                      └──────┬───────┘
                                             │
                                             ▼
                                      ┌──────────────┐
                                      │   DuckDB     │
                                      │  memories    │
                                      │  edges       │
                                      │  consolids   │
                                      └──────┬───────┘
                                             │
                          ┌──────────────────┼──────────────────┐
                          │                  │                  │
                          ▼                  ▼                  ▼
                   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐
                   │  Rgano Edge │   │ Consolidate │   │    Query    │
                   │  Detection  │   │   (timer)   │   │   Engine    │
                   │             │◄──│             │   │  (topology  │
                   │ edge_score= │   │ LLM synth + │   │   aware)   │
                   │ 1-consensus │   │ edge-aware   │   │             │
                   └─────────────┘   └─────────────┘   └─────────────┘
```

## Project Structure

```
always-on-memory/
├── Cargo.toml
├── config.toml
├── src/
│   ├── main.rs          # Entry: spawns watcher, timer, API server
│   ├── config.rs        # TOML configuration
│   ├── db.rs            # DuckDB memory store (collection-scoped)
│   ├── llm.rs           # LLM client (Ollama / LocalAI / exo / OpenAI-compat)
│   ├── ingest.rs        # File watcher + content extraction
│   ├── consolidate.rs   # Timer-driven consolidation cycles
│   ├── edges.rs         # Rgano edge detection (the secret sauce)
│   ├── query.rs         # Topology-aware query engine
│   ├── api.rs           # Native Axum HTTP API
│   └── localrecall.rs   # LocalRecall-compatible API (LocalAGI drop-in)
└── inbox/               # Drop files here
```

## Stack

- **Rust 2024** with Tokio async runtime
- **Axum** for the HTTP API (native + LocalRecall-compat)
- **DuckDB** for columnar memory storage
- **notify** for filesystem watching
- **tracing** for structured logging
- Any **Ollama**, **LocalAI**, **exo**, or **OpenAI-compatible** LLM endpoint
- Drop-in **LocalRecall** replacement for **LocalAGI** integration
